package customer;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Start extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	{
		 int creditCardAccountsp=request.getParameter("accounts");
		int duedaysp =request.getParameter("days");
		 boolean bankruptcyp=request.getParameter("filled");
		 boolean marriedp=request.getParameter("status");
		 boolean crimerecordp=;
		 String education="";
		 double ratio=0.0d;
		
	}
	

	
		
	
	
}
