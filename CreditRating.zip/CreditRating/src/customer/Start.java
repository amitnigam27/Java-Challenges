package customer;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Start extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		 String creditCardAccountsp=request.getParameter("accounts");
		 String duedaysp =request.getParameter("days");
		 String bankruptcyp=request.getParameter("filled");
		 String marriedp=request.getParameter("status");
		 String crimerecordp=request.getParameter("crime");
		 String educationp=request.getParameter("browser");
		 String ratiop=request.getParameter("ratio");
		 
		 int accounts=Integer.valueOf(creditCardAccountsp);
		 int days=Integer.valueOf(duedaysp);
		 boolean filled = Boolean.valueOf(bankruptcyp);
		 boolean status=Boolean.valueOf(marriedp);
		 boolean crime=Boolean.valueOf(crimerecordp);
		 String browser=String.valueOf(educationp);
		 double ratio=Double.valueOf(ratiop);
		 
		 CustomerInfo cf;
		 Validation vl=new Validation();
		 
		 cf=vl.validate(accounts, days, filled, status, crime, browser, ratio);
		 
		 PrintWriter pw = response.getWriter();
		 
		 pw.println("<html><body><h3>Number of Open Credit Card Accounts :"+cf.getCreditCardAccounts()+"</h3></body></html>");
		 pw.println("<html><body><h3>Number of Days Past Due : "+cf.getDuedays()+"</h3></body></html>");
		 pw.println("<html><body><h3>Bankruptcy filling anytime in past 10 years:"+cf.isBankruptcy()+"</h3></body></html>");
		 pw.println("<html><body><h3>Marrital Status:"+cf.isMarried()+"</h3></body></html>");
		 pw.println("<html><body><h3>Criminal Record:"+cf.isCrimerecord()+"</h3></body></html>");
		 pw.println("<html><body><h3>Education Level:"+cf.getEducation()+"</h3></body></html>");
		 pw.println("<html><body><h3>Annual Income to Debit Ratio: "+cf.getRatio()+"</h3></body></html>");	
		 pw.println("<html><body><h1>Your Credit Rating is :"+cf.getRating()+"</h1></body></html>");
	
	
	}
	

	
		
	
	
}
