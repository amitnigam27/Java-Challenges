package customer;

public class CustomerInfo {
	
	private int creditCardAccounts=0;
	private int duedays=0;
	private boolean bankruptcy=false;
	private boolean married=false;
	private boolean crimerecord=false;
	private String education="";
	private double ratio=0.0d;
	private char rating;
	
	
	public int getCreditCardAccounts() {
		return creditCardAccounts;
	}
	public void setCreditCardAccounts(int creditCardAccounts) {
		this.creditCardAccounts = creditCardAccounts;
	}
	public int getDuedays() {
		return duedays;
	}
	public void setDuedays(int duedays) {
		this.duedays = duedays;
	}
	public boolean isBankruptcy() {
		return bankruptcy;
	}
	public void setBankruptcy(boolean bankruptcy) {
		this.bankruptcy = bankruptcy;
	}
	public boolean isMarried() {
		return married;
	}
	public void setMarried(boolean married) {
		this.married = married;
	}
	public boolean isCrimerecord() {
		return crimerecord;
	}
	public void setCrimerecord(boolean crimerecord) {
		this.crimerecord = crimerecord;
	}
	public String getEducation() {
		return education;
	}
	
	public void setEducation(String education) {
		this.education = education;
	}

	public double getRatio() {
		return ratio;
	}
	public void setRatio(double ratio) {
		this.ratio = ratio;
	}
	public char getRating() {
		return rating;
	}
	public void setRating(char rating) {
		this.rating = rating;
	}
	
	
	

}
