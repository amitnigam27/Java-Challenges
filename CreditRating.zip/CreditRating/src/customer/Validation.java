package customer;

public class Validation {
	
	public CustomerInfo validate(int creditCardAccounts, int duedays, boolean bankruptcy, boolean married,	boolean crimerecord, String education, double ratio) 
	{
		CustomerInfo ci=new CustomerInfo();
		ci.setCreditCardAccounts(creditCardAccounts);
		ci.setDuedays(duedays);
		ci.setBankruptcy(bankruptcy);
		ci.setMarried(married);
		ci.setCrimerecord(crimerecord);
		ci.setEducation(education);
		ci.setRatio(ratio);
		
		
		int TotalPoints=0;
		if(creditCardAccounts>=0 && creditCardAccounts<=1)
			TotalPoints=TotalPoints+0;		
		else if(creditCardAccounts>=2 && creditCardAccounts<=3)
			TotalPoints=TotalPoints+1;
		else if(creditCardAccounts>=4 && creditCardAccounts<=5)
			TotalPoints=TotalPoints+3;
		else if(creditCardAccounts>5)
			TotalPoints=TotalPoints+5;
		
		
		
		if(duedays>=0 && duedays<=30)
			TotalPoints=TotalPoints+1;
		else if(duedays>=31 && duedays<=60)
			TotalPoints=TotalPoints+3;	
		else if(duedays>=61 && duedays<=90)
			TotalPoints=TotalPoints+5;		
		else if(duedays>=90 )
			TotalPoints=TotalPoints+7;
	
	
		
		if(bankruptcy==true) {
		TotalPoints=TotalPoints+10;
		}
		else { TotalPoints=TotalPoints;}
		
		if(married==true)
			TotalPoints=TotalPoints-3;
		else TotalPoints=TotalPoints;
		
		if(crimerecord==true)
			TotalPoints=TotalPoints+5;
		else TotalPoints=TotalPoints;
		
		
		if(education.equals("some high school"))
			TotalPoints=TotalPoints+2;
		else if(education.equals("high school grad or GED"))
			TotalPoints=TotalPoints+0;
		else if(education.equals("some college"))
			TotalPoints=TotalPoints-1;
		else if(education.equals("college grad"))
			TotalPoints=TotalPoints-2;
		
		
		if(ratio<0.25)
			TotalPoints=TotalPoints-2;
		else if(ratio>0.25 && ratio<=1.0)
			TotalPoints=TotalPoints+1;
		else if(ratio>1.0 && ratio<=2.0)
			TotalPoints=TotalPoints+2;
		else if(ratio>2.0 && ratio<=3.0)
			TotalPoints=TotalPoints+3;
		else if(ratio>3.0)
			TotalPoints=TotalPoints+5;
		
		
		if(TotalPoints<=0)
			ci.setRating('A');
		else if(TotalPoints>=1 && TotalPoints<=5)
			ci.setRating('B');
		else if(TotalPoints>=6 && TotalPoints<=9)
			ci.setRating('C');
		else if(TotalPoints>=10 && TotalPoints<=14)
			ci.setRating('D');
		else if(TotalPoints>=15)
			ci.setRating('E');
		
		
		return ci;
	
	}
	
	
}
